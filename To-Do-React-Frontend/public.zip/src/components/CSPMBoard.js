// CSPMBoard.js
import React from 'react';
import Board from './Board';

const CSPMBoard = () => {
  return <Board />;
};

export default CSPMBoard;

// IntactBoard.js


const IntactBoard = () => {
  return <Board />;
};

export default IntactBoard;

// CloudOptGenBoard.js
import React from 'react';
import Board from './Board';

const CloudOptGenBoard = () => {
  return <Board />;
};

export default CloudOptGenBoard;
