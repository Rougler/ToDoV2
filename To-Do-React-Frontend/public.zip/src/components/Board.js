import React, { useState, useEffect, useContext } from "react";
import "./Board.css";
import DeleteColumn from "../components/DeleteColumn";
import CardDetail from "../components/CardDetail";
import axios from "axios";
import ProjectDropdown from "../components/ProjectDropdown";
import ProjectContext from "../components/ProjectContext"; 

const initialLists = ["Not-Start", "On-going", "Done", "Staging"];

const Board = () => {
  const [cards, setCards] = useState([]);
  const [lists, setLists] = useState(initialLists);
  const [selectedCard, setSelectedCard] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [newListTitle, setNewListTitle] = useState("");
  const [showAddListForm, setShowAddListForm] = useState(false);

  const { selectedProject, setSelectedProject, tabs, setTabs, managerNames, setManagerNames } = useContext(ProjectContext);

  useEffect(() => {
    const fetchTasks = async () => {
      try {
        const response = await axios.get("http://127.0.0.1:8000/todo/tasks/");
        setTasks(response.data);
      } catch (error) {
        console.error("Error fetching tasks:", error);
      }
    };

    fetchTasks();
  }, []);

  useEffect(() => {
    const mappedCards = tasks.map((task) => ({
      id: task.id,
      title: task.taskName,
      listTitle: task.taskStatus,
      cover: task.cover,
      projectName: task.project,
    }));

    setCards(mappedCards);
  }, [tasks]);

  const deleteCard = (cardId) => {
    setCards(cards.filter((card) => card.id !== cardId));
    setSelectedCard(null);
  };

  const moveCard = (cardId, newListTitle) => {
    const updatedCards = cards.map((card) =>
      card.id === cardId ? { ...card, listTitle: newListTitle } : card
    );
    setCards(updatedCards);
  };

  const saveTitle = (cardId, newTitle) => {
    const updatedCards = cards.map((card) =>
      card.id === cardId ? { ...card, title: newTitle } : card
    );
    setCards(updatedCards);
  };

  const saveCoverColor = (cardId, newColor) => {
    const updatedCards = cards.map((card) =>
      card.id === cardId ? { ...card, cover: newColor } : card
    );
    setCards(updatedCards);
  };

  const addList = (listTitle) => {
    if (listTitle.trim() === "") return;
    setLists([...lists, listTitle]);
    setShowAddListForm(false);
  };

  const deleteList = (listTitle) => {
    setLists(lists.filter((list) => list !== listTitle));
    setCards(cards.filter((card) => card.listTitle !== listTitle));
  };

  const handleMoveCard = (cardId, newListTitle) => {
    moveCard(cardId, newListTitle);
  };

  const handleDeleteCard = (cardId) => {
    deleteCard(cardId);
  };

  const handleSaveTitle = (cardId, newTitle) => {
    saveTitle(cardId, newTitle);
  };

  const handleSaveCoverColor = (cardId, newColor) => {
    saveCoverColor(cardId, newColor);
  };

  const handleCopyCard = (card) => {
    const newCard = {
      ...card,
      id: cards.length + 1,
      title: `${card.title} (Copy)`,
    };
    const index = cards.findIndex((c) => c.id === card.id);
    const updatedCards = [
      ...cards.slice(0, index + 1),
      newCard,
      ...cards.slice(index + 1),
    ];
    setCards(updatedCards);
  };

  const handleAddList = (e) => {
    e.preventDefault();
    addList(newListTitle);
    setNewListTitle("");
  };

  const getCardsForCurrentTab = (listTitle) => {
    return cards.filter(
      (card) =>
        card.listTitle === listTitle &&
        card.projectName ===
          tabs.find((tab) => tab.value === selectedProject)?.label
    );
  };

  return (
    <div>
      <div className="board">
        {tabs.map(
          (tab) =>
            selectedProject === tab.value && (
              <div key={tab.value}>
                <div className="managerName">
                  Project Manager: {managerNames[tab.value] || "N/A"}
                </div>
                <div key={tab.value} className="lists-container">
                  {lists.map((listTitle, index) => (
                    <div key={index} className="list">
                      <div className="list-header">
                        <h3>{listTitle}</h3>
                        <DeleteColumn
                          listTitle={listTitle}
                          onDelete={deleteList}
                        />
                      </div>
                      <div className="cards">
                        {getCardsForCurrentTab(listTitle).map((card) => (
                          <div
                            key={card.id}
                            className="card"
                            onClick={() => setSelectedCard(card)}
                            style={{ backgroundColor: card.cover }}
                          >
                            {card.title}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )
        )}

        {selectedCard && (
          <CardDetail
            card={selectedCard}
            lists={lists}
            onMove={handleMoveCard}
            onClose={() => setSelectedCard(null)}
            onDelete={handleDeleteCard}
            onSaveTitle={handleSaveTitle}
            onSaveCoverColor={handleSaveCoverColor}
            onCopyCard={handleCopyCard}
          />
        )}
      </div>
    </div>
  );
};

export default Board;
