// IntactBoard.js
import React from 'react';
import Board from './Board';

const IntactBoard = () => {
  return (
    <div>
      <Board />
    </div>
  );
};

export default IntactBoard;
