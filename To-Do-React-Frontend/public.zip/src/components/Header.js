// // Header.js
// import React from 'react';
// import { Link } from 'react-router-dom';
// import './Header.css';

// const Header = () => {
//   return (
//     <div className="header">
//       <h1>Projects</h1>
//       <div className="nav-buttons">
//         <Link to="/cspm">
//           <button>CSPM</button>
//         </Link>
//         <Link to="/intact">
//           <button>Intact</button>
//         </Link>
//         <Link to="/cloudopt-gen">
//           <button>CloudOpt Gen</button>
//         </Link>
//         <button>Add Project</button>
//       </div>
//     </div>
//   );
// };

// export default Header;
